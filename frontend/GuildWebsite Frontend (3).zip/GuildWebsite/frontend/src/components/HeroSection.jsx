import React from 'react';

const HeroSection = () => {
  return (
    <div className="hero-content">
      <h1>LOREM IPSUM DOLOR<br />SIT AMET</h1>
      <p>Lorem ipsum dolor sit amet.</p>
      <button>See more</button>
    </div>
  );
};

export default HeroSection;