import React from 'react'

const Events = () => {
  return (
    <div>
      
    </div>
  )
}

export default Events
