import React from 'react';
import Navbar from "../components/Navbar";
import HeroSection from "../components/HeroSection";
import '../index.css'; 

const Home = () => {
  return (
    <div className="main-container">
      <div className="folder-tab">
        <Navbar />
        {/* Sidebar if needed */}
        <HeroSection />
      </div>
    </div>
  );
};

export default Home;
